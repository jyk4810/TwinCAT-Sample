// CoETestTwincat.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include <iostream>
#include <windows.h>
#include <conio.h> 
#include "C:\TwinCAT\ADSApi\TcAdsDll\Include\TcAdsDef.h"
#include "C:\TwinCAT\ADSApi\TcAdsDll\Include\TcAdsAPI.h"

#pragma comment(lib, "TcAdsDll.lib")

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{

	long nErr, nPort;
	AmsAddr Addr;
	PAmsAddr pAddr = &Addr;
	BYTE Data;
	// ADS ������� ��� ��Ʈ�� ����.
	nPort = AdsPortOpen();
	nErr = AdsGetLocalAddress(pAddr);
	if(nErr != ADSERR_NOERR) 
		printf("Error: AdsGetLocalAddress: %d\n", nErr);

	unsigned long GroupIndex, Offset;
	//NetId (LAN ��Ʈ ���� �Ҵ�Ǵ� ID)
	pAddr->netId.b[0] = 192;
	pAddr->netId.b[1] = 168;
	pAddr->netId.b[2] = 1;
	pAddr->netId.b[3] = 81;
	pAddr->netId.b[4] = 3;
	pAddr->netId.b[5] = 1;

	//CoE Read Vendor ID	(Index : 0x1018, SubIndex : 0x0001)
	pAddr->port = 1001;		//EtherCAT Addr
	GroupIndex = 0xF302;	//Fixed Value(CoE)
	Offset = 0x10180001;	//Index, Sub-Index
	DWORD VendorId = 0;
	nErr = AdsSyncReadReq( pAddr, GroupIndex, Offset, 4, &VendorId );
	if(nErr != ADSERR_NOERR) 
		printf("Error: AdsSyncReadReq: %d\n", nErr);

	printf("Vendor ID : 0x%02X\n", VendorId);

	// Wait for key
	_getch();
	// ��� ��Ʈ�� �ݴ´�.
	nErr = AdsPortClose();
	if(nErr != ADSERR_NOERR) 
		printf("Error: AdsPortClose: %d\n", nErr);

	return 0;
}

